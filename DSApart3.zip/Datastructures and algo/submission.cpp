#include <iostream>
#include <fstream>
#include <string>
using namespace std;

const int MAX_ITEMS = 100;
const string FILENAME = "contacts.txt";

class ItemType {
private:
    string name;
    string phone;
    string address;
public:
    ItemType() {}
    ItemType(string n, string p, string a) {
        name = n;
        phone = p;
        address = a;
    }

    string GetName() { return name; }
    string GetPhone() { return phone; }
    string GetAddress() { return address; }

    void Print() {
        cout << "Name    : " << name << endl;
        cout << "Phone   : " << phone << endl;
        cout << "Address : " << address << endl;
    }
};

class SortedType {
private:
    ItemType info[MAX_ITEMS];
    int length;
public:
    SortedType() {
        length = 0;
    }

    bool IsFull() { return length == MAX_ITEMS; }
    bool IsEmpty() { return length == 0; }
    int GetLength() { return length; }

    // Simple insertion (sorted by name)
    void InsertItem(ItemType item) {
        if (IsFull()) {
            cout << "List is full. Cannot insert.\n";
            return;
        }
        int pos = 0;
        while (pos < length && info[pos].GetName() < item.GetName()) {
            pos++;
        }
        for (int i = length; i > pos; i--) {
            info[i] = info[i-1];
        }
        info[pos] = item;
        length++;
        cout << "Contact added.\n";
    }

    // Linear search
    bool RetrieveByName(string name, ItemType &out) {
        for (int i = 0; i < length; i++) {
            if (info[i].GetName() == name) {
                out = info[i];
                return true;
            }
        }
        return false;
    }

    // Delete by name
    bool DeleteByName(string name) {
        for (int i = 0; i < length; i++) {
            if (info[i].GetName() == name) {
                for (int j = i; j < length-1; j++) {
                    info[j] = info[j+1];
                }
                length--;
                return true;
            }
        }
        return false;
    }

    void DisplayAll() {
        if (IsEmpty()) {
            cout << "No contacts.\n";
            return;
        }
        for (int i = 0; i < length; i++) {
            cout << "----------------\n";
            info[i].Print();
        }
        cout << "----------------\nTotal: " << length << endl;
    }

    // Save to file
    void SaveToFile() {
        ofstream fout;
        fout.open(FILENAME.c_str(), ios::out);  // <-- using ios::out
        for (int i = 0; i < length; i++) {
            fout << info[i].GetName() << endl;
            fout << info[i].GetPhone() << endl;
            fout << info[i].GetAddress() << endl;
        }
        fout.close();
    }

    // Load from file
    void LoadFromFile() {
        ifstream fin;
        fin.open(FILENAME.c_str(), ios::in);  // <-- using ios::in
        if (!fin) return;
        length = 0;
        string n, p, a;
        while (getline(fin, n) && getline(fin, p) && getline(fin, a)) {
            InsertItem(ItemType(n, p, a));
        }
        fin.close();
    }
};

int main() {
    SortedType contacts;
    contacts.LoadFromFile();

    while (true) {
        cout << "\n===== Contact Manager =====\n";
        cout << "1) Add Contact\n";
        cout << "2) Search Contact\n";
        cout << "3) Delete Contact\n";
        cout << "4) Display All Contacts\n";
        cout << "5) Save & Exit\n";
        cout << "Choose: ";

        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string n, p, a;
            cout << "Enter name: "; getline(cin, n);
            cout << "Enter phone: "; getline(cin, p);
            cout << "Enter address: "; getline(cin, a);
            contacts.InsertItem(ItemType(n, p, a));
        }
        else if (choice == 2) {
            string n;
            cout << "Enter name to search: ";
            getline(cin, n);
            ItemType found;
            if (contacts.RetrieveByName(n, found)) {
                cout << "Contact found:\n";
                found.Print();
            } else {
                cout << "Not found.\n";
            }
        }
        else if (choice == 3) {
            string n;
            cout << "Enter name to delete: ";
            getline(cin, n);
            if (contacts.DeleteByName(n)) {
                cout << "Contact deleted.\n";
            } else {
                cout << "Not found.\n";
            }
        }
        else if (choice == 4) {
            contacts.DisplayAll();
        }
        else if (choice == 5) {
            contacts.SaveToFile();
            cout << "Contacts saved. Goodbye!\n";
            break;
        }
        else {
            cout << "Invalid choice.\n";
        }
    }
    return 0;
}
