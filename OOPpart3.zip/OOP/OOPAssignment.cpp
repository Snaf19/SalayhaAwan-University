﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.11.35327.3
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "OOPAssignment", "OOPAssignment\OOPAssignment.vcxproj", "{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Debug|x64.ActiveCfg = Debug|x64
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Debug|x64.Build.0 = Debug|x64
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Debug|x86.ActiveCfg = Debug|Win32
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Debug|x86.Build.0 = Debug|Win32
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Release|x64.ActiveCfg = Release|x64
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Release|x64.Build.0 = Release|x64
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Release|x86.ActiveCfg = Release|Win32
		{3E9EAD8E-21A8-4884-B9CA-55CB8F9B33C5}.Release|x86.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {2960AFE6-23D5-4757-B69F-4558A6DBA19E}
	EndGlobalSection
EndGlobal
